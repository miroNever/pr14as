﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Практика_14
{
    public class LocalPerfomances : Perfomances
    {
        private string nameP;
        private int count;
        public string NameP 
        {
            get { return nameP; }
            set { nameP = value; }
        }
        public int Count
        {
            get { return count; }
            set { count = value; }
        }
        public LocalPerfomances(string nameP, int count, string name, string genre, string autor, string director) : base(name, genre, autor, director)
        {
            this.nameP = nameP;
            this.count = count;
        }
        public override string Info()
        {
            return$"Название спектакля {this.Name}\n" + 
                $"Жанр спектакля {this.Genre}\n" + 
                $"Автор спектакля {this.Autor}\n" + 
                $"Режисер спектакля {this.Director}\n" + 
                $"Название театра {NameP}\n" + 
                $"Кол-во раз в сезоне {Count}";
        }
    }
}
