﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Практика_14
{
    public abstract class Perfomances
    {
        private string name;
        private string genre;
        private string autor;
        private string director;
        public string Name
        {
            get { return name;}
            set { name = value; }
        }
        public string Genre
        {
            get { return genre; }
            set { genre = value; }
        }
        public string Autor
        {
            get { return autor; }
            set { autor = value; }
        }
        public string Director
        {
            get { return director; }
            set { director = value; }
        }
        public Perfomances(string name, string genre, string autor, string director)
        { 
            this.name = name;
            this.genre = genre;
            this.autor = autor;
            this.director = director;
        }
        public abstract string Info();
    }
}
