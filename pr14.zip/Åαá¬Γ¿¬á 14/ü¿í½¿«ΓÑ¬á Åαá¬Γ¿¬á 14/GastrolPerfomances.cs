﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Практика_14
{
    public class GastrolPerfomances : Perfomances
    {
        private string begining;
        private string end;
        private string area;
        public string Begining
        {
            get { return begining; }
            set { begining = value; }
        }
        public string End
        {
            get { return end; }
            set { end = value; }
        }
        public string Area
        {
            get { return area;}
            set { area = value; }
        }
        public GastrolPerfomances(string begining, string end, string area, string name, string genre, string autor, string director) : base(name, genre, autor, director)
        {
            this.begining = begining;
            this.end = end;
            this.area = area;
        }
        public override string Info()
        {
            return $"Название спектакля {this.Name}\n" +
                $"Жанр спектакля {this.Genre}\n" +
                $"Автор спектакля {this.Autor}\n" +
                $"Режисер спектакля {this.Director}\n" +
                $"Начало гастролей {Begining}\n" +
                $"Конец гастролей {End}\n" +
                $"Площадка гастролей {area}";
        }
    }
}
