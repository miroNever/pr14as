﻿using Практика_14;


static string CheckString()
{
    while (true)
    {
        Console.WriteLine("Введите строку:");
        bool test = false;
        string str = Console.ReadLine();
        if (str.Length == 0)
            Console.WriteLine("Вы ввели пустую строку");
        else
        {
            foreach (char c in str)
            {
                if (!char.IsLetter(c))
                    test = true;
            }
            if (test == true)
                Console.WriteLine("Можно использовать только буквы");
            else
                return str;
        }
    }
}
static int CheckNumber()
{
    while (true)
    {
        try
        {
            Console.WriteLine("введите число");
            int num = int.Parse(Console.ReadLine());
            if (num > 0)
            {
                return num;
            }
        }
        catch (Exception)
        {
            Console.WriteLine("Введите число");
        }
    }
}
static string CheckDate()
{

    while (true)
    {
        Console.WriteLine("введите день");
        int d = int.Parse(Console.ReadLine());
        while (true)
        {
            if (d > 0 && d <= 31)
            {
                break;
            }
            else
            {
                Console.WriteLine("Введите день (0 - 31)");
                d = int.Parse(Console.ReadLine());
            }
        }
        Console.WriteLine("введите месяй");
        int m = int.Parse(Console.ReadLine());
        while (true)
        {
            if (m > 0 && m <= 12)
            {
                break;
            }
            else
            {
                Console.WriteLine("Введите месяц (0 - 12)");
                m = int.Parse(Console.ReadLine());
            }
        }
        Console.WriteLine("введите год");
        int y = int.Parse(Console.ReadLine());
        while (true)
        {
            if (y > 0 && y <= 2023)
            {
                break;
            }
            else
            {
                Console.WriteLine("Введите год (0 - 2023)");
                y = int.Parse(Console.ReadLine());
            }
        }
        DateTime dt = new DateTime(y, m, d);
        return dt.ToString();
        dt = new DateTime();
    }
}
List<Perfomances> intst = new List<Perfomances>();
while (true)
{
    Console.WriteLine("Добавить? (да/нет)");
    if (Console.ReadLine() == "да")
    {
        Console.WriteLine("Локальный театр(1) / Гастроли(2)");
        string a = Console.ReadLine();
        if (a == "1")
        {
            Console.WriteLine("Введите начало гастролей, конец гастролей, площадку гастролей, название спектакля, жанр спектакля, автора спектакля, режисёра спектакля");
            GastrolPerfomances gp = new GastrolPerfomances(CheckDate(), CheckDate(), CheckString(), CheckString(), CheckString(), CheckString(), CheckString());
            Console.WriteLine("____________________________________");
            intst.Add(gp);
            Console.WriteLine(gp.Info());
            Console.WriteLine("____________________________________");
        }
        else if (a == "2")
        {
            Console.WriteLine("Введите название театра, кол-во раз в сезоне, название спектакля, жанр спектакля, автора спектакля, режисёра спектакля");
            LocalPerfomances lp = new LocalPerfomances(CheckString(), CheckNumber(), CheckString(), CheckString(), CheckString(), CheckString());
            Console.WriteLine("____________________________________");
            intst.Add(lp);
            Console.WriteLine(lp.Info());
            Console.WriteLine("____________________________________");
        }
        else Console.WriteLine("выбери 1 или 2");
    }
    else break;
} 
StreamWriter sw = File.CreateText("file.txt");
foreach (Perfomances teatr in intst)
{
    sw.WriteLine(teatr.Info());
}
sw.Close();

